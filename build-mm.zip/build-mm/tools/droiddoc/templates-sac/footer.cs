<div id="footer" class="wrap" <?cs if:fullpage ?>style="width:940px"<?cs /if ?>>
  <div id="copyright">
    <?cs call:custom_cc_copyright() ?>
  </div>
    <div id="footerlinks">
    <?cs call:custom_footerlinks() ?>
  </div>
