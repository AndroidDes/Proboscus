<?cs if:sac ?>
  <?cs call:sac_masthead() ?>
  <?cs call:sac_left_nav() ?>
<?cs else ?>
  <?cs call:custom_masthead() ?>
  <?cs call:custom_left_nav() ?>
<?cs /if ?>
