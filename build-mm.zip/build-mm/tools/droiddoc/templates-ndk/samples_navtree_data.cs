var SAMPLES_NAVTREE_DATA =
<?cs var:reference_tree ?>
;
