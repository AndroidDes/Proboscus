package com.android.stubs;
@java.lang.annotation.Documented()
@java.lang.annotation.Retention(value=java.lang.annotation.RetentionPolicy.RUNTIME)
@java.lang.annotation.Target(value={java.lang.annotation.ElementType.TYPE})
public @interface Annot
{
java.lang.String value() default "yo\u1234";
}
