__author__ = 'arnav'

g_url = "gerrit.aokp.co"
g_port = 29418

g_proj_basedir = "AOKP/"
